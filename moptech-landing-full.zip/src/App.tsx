import React from 'react';
import MOPLandingPage from './MOPLandingPage';

function App() {
  return <MOPLandingPage />;
}

export default App;
