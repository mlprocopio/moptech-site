# MOP Tecnologia - Landing Page

Landing Page moderna desenvolvida em React + Tailwind + Framer Motion.

## Scripts
- `npm install` - instalar dependências
- `npm run dev` - rodar em desenvolvimento
- `npm run build` - gerar build de produção

---
